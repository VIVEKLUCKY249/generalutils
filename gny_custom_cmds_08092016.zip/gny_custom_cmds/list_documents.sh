#!/bin/bash

OPEN_FILES_LIST=$(geany --list-documents);
echo "${OPEN_FILES_LIST}";
exit;
