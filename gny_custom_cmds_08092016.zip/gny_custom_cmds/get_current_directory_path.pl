#!/usr/bin/perl -w

# print $ARGV[0];
use strict;
use warnings FATAL => 'all';
use diagnostics;

use Clipboard;

foreach $argnum (0 .. $#ARGV) {
    print "$ARGV[$argnum]\n";
    Clipboard->copy($ARGV[$argnum]);
    print Clipboard->paste;
}
