#!/bin/bash
CURRENT_DIR_PATH="$GEANY_FILENAME";
echo -n ${CURRENT_DIR_PATH} | xsel -ib;
exit;