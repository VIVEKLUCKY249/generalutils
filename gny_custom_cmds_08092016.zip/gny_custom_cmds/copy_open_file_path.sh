#!/bin/bash
CURRENT_DIR_PATH="$1";
##echo "${CURRENT_DIR_PATH}";
echo -n ${CURRENT_DIR_PATH} | xsel -ib;
exit;
