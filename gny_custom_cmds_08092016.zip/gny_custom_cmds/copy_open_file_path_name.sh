#!/bin/bash
old="$IFS"
IFS='/'
fileDetails="$*"
echo "$str"
IFS=$old
echo -n ${fileDetails} | xsel -ib;
exit;
