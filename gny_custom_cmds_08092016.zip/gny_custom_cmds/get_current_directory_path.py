#!/usr/bin/env python
import sys
import re
from sys import stdin
# print(sys.argv[1])
'''
import Tkinter as tk
from Tkinter import Tk
root = tk.Tk()
# keep the window from showing
root.withdraw()
text = sys.argv[1]
root.clipboard_clear()
# text to clipboard
root.clipboard_append(text)
# text from clipboard
clip_text = root.clipboard_get()
'''
'''
import Tkinter
from Tkinter import Tk
r = Tk()
r.withdraw()
r.clipboard_clear()
r.clipboard_append(sys.argv[1])
# r.destroy()
'''

import pyperclip
newtext = re.sub('.*(?=/app)',"", sys.argv[1])
print(newtext)
pyperclip.copy(newtext)
spam = pyperclip.paste()

'''
try:
    from Tkinter import Tk
except ImportError:
    # welcome to Python3
    from tkinter import Tk
    raw_input = input

r = Tk()
r.withdraw()
r.clipboard_clear()

if len(sys.argv) < 2:
    data = sys.stdin.read()
else:
    data = ' '.join(sys.argv[1:])

r.clipboard_append(data)

if sys.platform != 'win32':
    if len(sys.argv) > 1:
        raw_input('Data was copied into clipboard. Paste and press ENTER to exit...')
    else:
        # stdin already read; use GUI to exit
        print('Data was copied into clipboard. Paste, then close popup to exit...')
        r.deiconify()
        r.mainloop()
else:
    r.destroy()
'''
