<?php
ini_set('display_errors',1);
error_reporting(E_ALL);

require_once('Client.php');
require_once('Logging.php');
require_once('GrantType/IGrantType.php');
require_once('GrantType/AuthorizationCode.php');

const CLIENT_ID = 'webexpressen';
const CLIENT_SECRET = 'uncwq7im4hXq8sn8J7G29Uyh1E8LTQxGs4lYH63ag';

#const REDIRECT_URI = 'http://192.168.0.106/oauth2/';
const REDIRECT_URI = 'http://115.112.143.20/oauth2/';
const AUTHORIZATION_ENDPOINT = 'https://auth-sandbox.test.vismaonline.com/eaccountingapi/oauth/authorize';
const TOKEN_ENDPOINT = 'https://auth-sandbox.test.vismaonline.com/eaccountingapi/oauth/token';

$log = new Logging();
// set path and name of log file (optional)
$log->lfile($_SERVER["DOCUMENT_ROOT"].'/oauth2/customPhp.log');

$client = new OAuth2\Client(CLIENT_ID, CLIENT_SECRET);
if(!isset($_GET['code']))
{
	$auth_url = $client->getAuthenticationUrl(AUTHORIZATION_ENDPOINT, REDIRECT_URI);
	$log->lwrite("\nAUTH_URL:".$auth_url);	
	header('Location: ' . $auth_url);
	die('Redirect');
}
else
{
	$log->lwrite("\nIN ELSE");
	$params = array('code' => $_GET['code'], 'redirect_uri' => REDIRECT_URI);
	$response = $client->getAccessToken(TOKEN_ENDPOINT, 'authorization_code', $params);
	parse_str($response['result'], $info);
	$client->setAccessToken($info['access_token']);
	$response = $client->fetch('https://auth-sandbox.test.vismaonline.com/');
	var_dump($response, $response['result']);
}

// close log file
$log->lclose();
